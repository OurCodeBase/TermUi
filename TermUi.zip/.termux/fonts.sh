#!/data/data/com.termux/files/usr/bin/bash
DIR=`cd $(dirname $0) && pwd`
FONTS_DIR=$DIR/fonts
count=0

for font in $FONTS_DIR/*/{*.ttf,*.otf}; do
	font_file[count]=$font;
	count=$(( $count + 1));
done;
count=$(( $count - 1 ));

while true; do
	read -p 'Enter: ' number;

	if [[ -z "$number" ]]; then
		break;
	elif ! [[ $number =~ ^[0-9]+$ ]]; then
		echo "Just press enter: ";
	elif (( $number >= 0 && $number <= $count )); then
		cp -fr "${font_file[number]}" "$DIR/font.ttf";
		break;
	else
		echo "Just press enter: ";
	fi
done;

termux-reload-settings